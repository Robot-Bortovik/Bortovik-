import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont

model = load_model('ship_defect_model_simple1.h5')

filename = 'dents.jpg'


class_names = ['коррозия', 'трещины', 'вмятины']

# Подготовка изображения
def prepare_image(img_path, target_size=(256, 256)):
    img = image.load_img(img_path, target_size=target_size)
    img_array = image.img_to_array(img)
    img_array = img_array.astype('float32') / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array

# Получение предсказания
img_array = prepare_image(filename)
prediction = model.predict(img_array)
class_index = np.argmax(prediction)
class_name = class_names[class_index]

original_img = Image.open(filename).convert("RGB")
draw = ImageDraw.Draw(original_img)

try:
    font = ImageFont.truetype("arial.ttf", 36)
except:
    font = ImageFont.load_default()



plt.imshow(original_img)
plt.axis('off')
plt.title(class_name)
plt.show()
